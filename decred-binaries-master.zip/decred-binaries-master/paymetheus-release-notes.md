# [v0.0.8_paymetheus](https://github.com/decred/decred-binaries/releases/tag/v0.0.8_paymetheus)

## 2016-03-25

This is a testnet pre-release build of the Paymetheus Decred port for Windows.

See manifest-paymetheus-20160325-01.txt for sha256sums of the packages and
manifest-paymetheus-20160325-01.txt.asc to confirm those shas.

See [README.md](./README.md#verifying-binaries) for more info on verifying the files.

## Commits

This release was built from:

| Repository | Commit Hash |
| --- | ---- |
| decred/dcrd | 967952c7cbf23a622cf5ada5101658037f827a2f |
| decred/dcrwallet | b0aff95cbcd3d3d5e465abd59109cad733308d28 |
| decred/dcrrpcclient | b3f48780a0d68e24ef6e915e930a1c1e58b69810 |
| decred/dcrutil | 9bb7f64962cee52bb46ce588aa91ef0e6e7bb1a9 |
| decred/Paymetheus | df607a6c517f5b8863223fc12346c34df2d16266 |
